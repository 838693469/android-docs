Some utilities that use libelf to create synthetic ELF files

