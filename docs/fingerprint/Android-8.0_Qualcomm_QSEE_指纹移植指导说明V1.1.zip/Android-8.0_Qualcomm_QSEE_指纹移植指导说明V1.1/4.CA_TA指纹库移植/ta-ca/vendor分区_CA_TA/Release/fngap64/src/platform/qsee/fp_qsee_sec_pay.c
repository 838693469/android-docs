#include <stdint.h>
#include <stringl.h>
#include <biometric_result.h>
#include <biometric_interrupt.h>

#include "fp_log.h"
#include "fp_ta_entry.h"

uint32_t last_finger_id = 0;

#define EXT_DATA_SIZE 128
static uint8_t ext_data_last_id[EXT_DATA_SIZE] = {0x00};
static bio_buffer g_bio_last_id = {ext_data_last_id, EXT_DATA_SIZE};
static bio_result g_bio_last_id_result = {BIO_AUTH_METHOD_NUMBER, false, BIO_NA, BIO_NA, BIO_NA};
extern uint64_t fp_ta_hw_auth_get_session_id(void);
void tz_app_cmd_handler(void *command, uint32_t cmdlen, void *response, uint32_t rsplen);

static int32_t fp_qsee_set_auth_last_id(bool match, uint32_t finger_id, uint32_t user_id)
{
    BIO_ERROR_CODE err = BIO_NO_ERROR;
    uint64_t session_id =  fp_ta_hw_auth_get_session_id();

    if (match)
    {
        LOGD("%s matched fingerid is %llu", __func__, finger_id);
        g_bio_last_id_result.method = BIO_FINGERPRINT_MATCHING;
        g_bio_last_id_result.result = true;
        g_bio_last_id_result.user_id = user_id;
        g_bio_last_id_result.user_entity_id = finger_id;
        g_bio_last_id_result.transaction_id = session_id;
        memcpy(g_bio_last_id.data, &finger_id, sizeof(uint32_t));
        g_bio_last_id.size = sizeof(uint32_t);
    }
    else
    {
        LOGD("%s unmatched!!", __func__);
        g_bio_last_id_result.method = BIO_FINGERPRINT_MATCHING;
        g_bio_last_id_result.result = false;
        g_bio_last_id_result.user_id = BIO_NA;
        g_bio_last_id_result.user_entity_id = BIO_NA;
        g_bio_last_id_result.transaction_id = BIO_NA;
        g_bio_last_id.size = 0;
    }

    err = bio_set_auth_result(&g_bio_last_id_result, &g_bio_last_id);
    if (err != BIO_NO_ERROR)
    {
        LOGE("%s set LastId bio result failed, error %d", __func__, err);
        return -1;
    }

    LOGE("%s set LastId bio result done!", __func__);
    return 0;
}

int32_t fp_sec_set_pass_id(uint32_t finger_id, uint32_t user_id, uint64_t timestamp)
{
    last_finger_id = finger_id;

    LOGD("%s enter, last_finger_id:0x%08X!!!", __func__, finger_id);

    if (finger_id != 0)
    {
        fp_qsee_set_auth_last_id(true, finger_id, user_id);
    }
    else
    {
        fp_qsee_set_auth_last_id(false, finger_id, user_id);
    }

    return 0;
}

#include <qsee_fs.h>
#include <qsee_sfs.h>

#define FP_IDS_LIST_PATH "/persist/data/fpdata/ifaa_fplist"

/* file format as below table */
/*-----------------------------------------------------
| 4bytes | 4bytes | 4bytes | 4bytes | 4bytes | 4bytes |
-------------------------------------------------------
| id_cnt |  id_1  |  id_2  |  id_3  |  id_4  |  id_5  |
------------------------------------------------------*/
static int fp_qsee_store_fp_ids_list(uint32_t fp_count, uint32_t *fp_ids_list)
{
    int ret = -1;
    int fd = -1;
    uint32_t file_buf[FINGER_MAX_COUNT + 1] = { 0 };
    uint32_t file_size = 0;

    LOGD("%s: enter, fp_count %d", __func__, fp_count);
    if (fp_count > FINGER_MAX_COUNT)
    {
        LOGE("%s: fp_count %d > %d", __func__, fp_count, FINGER_MAX_COUNT);
        return -ENOSPC;
    }
    if (!fp_count)
    {
        LOGD("%s: all fingers are removed, just del ifaa_fplist", __func__);
        qsee_sfs_rm(FP_IDS_LIST_PATH);
        return 0;
    }
    if (!fp_ids_list)
    {
        LOGE("%s: fp_ids_list buffer is NULL", __func__);
        return -EINVAL;
    }
    memset(file_buf, 0x00, (FINGER_MAX_COUNT + 1) * sizeof(uint32_t));
    file_size = (fp_count + 1) * sizeof(uint32_t);
    file_buf[0] = fp_count;
    memcpy(&file_buf[1], fp_ids_list, fp_count * sizeof(uint32_t));
    fd = qsee_sfs_open(FP_IDS_LIST_PATH, O_RDWR | O_CREAT | O_TRUNC);
    if (0 == fd)
    {
        ret = qsee_sfs_error(fd);
        LOGE("%s open&create fplist file with error %d", __func__, ret);
        return -EFAULT;
    }
    ret = qsee_sfs_write(fd, (char *)file_buf, file_size);
    if (ret != file_size)
    {
        LOGE("%s: qsee_sfs_write fp_idlist failed with error %d", __func__, ret);
    }
    ret = qsee_sfs_close(fd);
    if (0 != ret)
    {
        LOGE("%s: qsee_fs_close failed with error %d", __func__, ret);
        return -EFAULT;
    }

    return 0;
}

fpsensor_qsee_msg_header g_qsee_cmd;
fpsensor_qsee_msg_response g_qsee_rsp;
static int fp_qsee_get_fp_ids_list(uint32_t *fp_count, uint32_t *fp_ids_list)
{
    int ret = 0;
    int32_t cmd_len = sizeof(fpsensor_qsee_msg_header);
    int32_t rsp_len = sizeof(fpsensor_qsee_msg_response);

    fpsensor_qsee_msg_header *qseeCmd = &g_qsee_cmd;
    fpsensor_qsee_msg_response *qseeRsp = &g_qsee_rsp;
    memset(qseeCmd, 0x00, cmd_len);
    memset(qseeRsp, 0x00, rsp_len);

    LOGD("%s: enter", __func__);
    do
    {
        if (NULL == fp_ids_list)
        {
            ret = -EINVAL;
            LOGE("%s invalid parameter, fp_ids_list is NULL", __func__);
            break;
        }
        qseeCmd->fpCmd.c.no_payload_cmd.cmd_id = TCI_FP_CMD_GET_ENROLLED_FIDS;
        qseeCmd->cmdLen = sizeof(fp_cmd_no_payload_t);
        LOGE("%s: cmdLen:%d\n", __func__, qseeCmd->cmdLen);
        tz_app_cmd_handler(qseeCmd, cmd_len, qseeRsp, rsp_len);
        *fp_count = qseeRsp->fpRsp.r.get_enrol_fids_rsp.FidCnt;
        {
            uint8_t *pSrc = (uint8_t *)qseeRsp->fpRsp.r.get_enrol_fids_rsp.Fids;
            uint8_t *pDst = (uint8_t *)fp_ids_list;
            uint32_t i = 0;
            uint32_t count = *fp_count * sizeof(uint32_t);
            while (i++ < count)
            {
                *pDst++ = *pSrc++;
            }
        }
    }
    while (0);

    LOGD("%s exit, ret:0x%x", __func__, ret);
    return ret;
}

void fp_qsee_set_fp_ids_list(void)
{
    uint32_t fp_count = 0;
    uint32_t fp_ids_list[FINGER_MAX_COUNT] = { 0x00 };

    LOGD("%s: enter", __func__);
    fp_qsee_get_fp_ids_list(&fp_count, fp_ids_list);
    fp_qsee_store_fp_ids_list(fp_count, fp_ids_list);

    LOGD("%s: exit", __func__);
    return ;
}

uint32_t fp_sec_get_pass_id(void)
{
    return last_finger_id;
}

int32_t fp_sec_pay_init(void)
{
    return 0;
}
