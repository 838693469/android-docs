#ifndef __FP_LOG_H__
#define __FP_LOG_H__

#include <stdbool.h>
#include <qsee_log.h>

/*************************************************************************
*   Begin to define macros for printing log                             *
*************************************************************************/
#define FP_LOG_DEBUG_LEVEL   3
#define FP_LOG_INFO_LEVEL    2
#define FP_LOG_ERROR_LEVEL   1

#ifndef FP_LOG_LEVEL
#define FP_LOG_LEVEL  FP_LOG_DEBUG_LEVEL
#endif

/* debug */
#if( FP_LOG_LEVEL >= FP_LOG_DEBUG_LEVEL )
#define LOGD(fmt, args...)  QSEE_LOG(QSEE_LOG_MSG_ERROR, fmt, ## args)
#else
#define LOGD(fmt, args...)
#endif

/* info */
#if( FP_LOG_LEVEL >= FP_LOG_INFO_LEVEL )
#define LOGI(fmt, args...)  QSEE_LOG(QSEE_LOG_MSG_ERROR, fmt, ## args)
#else
#define LOGI(fmt, args...)
#endif

/* error */
#if( FP_LOG_LEVEL >= FP_LOG_ERROR_LEVEL )
#define LOGE(fmt, args...)  QSEE_LOG(QSEE_LOG_MSG_ERROR, fmt, ## args)
#else
#define LOGE(fmt, args...)
#endif

#endif /* __FP_LOG_H__ */

