#!/usr/bin/python
#coding=utf-8
import sys

def FF_Align(line):
	count = len(line) - 7
	temp = 4
	while temp < count:
		temp = temp + 4
	return (temp - count, temp + 4)

if len(sys.argv) < 2:
	print "缺少参数"
	print "etc: ./lcm_kernel2lk.py nt35596_tianma_fhd_video_c6lite"
	sys.exit(0)


f = open("temp")
str1 = []
str2 = []
count = 0
str_name = sys.argv[1]
for line in f:
	line = line.split()

	for i in range(len(line)):
		line[i] = "0x"+line[i]
	
	lkcmds = []
	lkcmds.insert(0, line[6] + ", ")
	lkcmds.insert(1, "0x00, ")
	lkcmds.insert(2, "0x29, ")
	lkcmds.insert(3, "0xC0, ")
	
	for i in range(0, len(line) - 7):
		lkcmds.append(line[7+i] + ", ")
	
	for i in range(0, FF_Align(line)[0]):
		lkcmds.append("0xFF, ")

	lkcmds.insert(0, "static char " + str_name + "_on_cmd" + str(count) +"[] = {")
	lkcmds.append("};\n")
	
	for i in range(0, len(lkcmds)):
		if (i % 4 == 0) and (i < (len(lkcmds) - 2)):
			lkcmds[i] = lkcmds[i] + "\n"

	lkcmds = ''.join(lkcmds)
	str1.append(''.join(lkcmds))
	#print lkcmds  

	lkcmds1 = []
	lkcmds1.append("{" + hex(FF_Align(line)[1]) + ", ")
	if lkcmds1[0] == "{0x8, ":
		lkcmds1[0] = "{0x08, "
	elif lkcmds1[0] == "{0xc, " or lkcmds1[0] == "{0xC, ":
		lkcmds1[0] = "{0x0C, "
	lkcmds1.append(str_name + "_on_cmd" + str(count) + ", ")
	lkcmds1.append(line[4] + "},")
	
	str2.append(''.join(lkcmds1))
	#print lkcmds1
	count = count + 1


print '\n'.join(str1)
print "static struct mipi_dsi_cmd "+ str_name + "_on_command[] = {"
print '\n'.join(str2)
print "};\n"
print "#define " + str_name.upper() + "_ON_COMMAND " + str(count)

sys.exit(0)
