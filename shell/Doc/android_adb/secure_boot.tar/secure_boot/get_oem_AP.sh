#!/bin/bash
#########################################################################
# File Name: get_security.sh
# Author: WangSen
# Email: wangs_hs@163.com
# Created Time: 2018年03月29日 星期四 14时43分31秒
#########################################################################

### KBA-000000031142

### mmm system/extras/verity/

make_key=development/tools/make_key
generate_verity_key=out/host/linux-x86/bin/generate_verity_key
keystore_signer=out/host/linux-x86/bin/keystore_signer
#self_certs=./build/target/product/security/self_certs
self_certs=./AP_certs

subject='/C=US/ST=California/L=Mountain View/O=Android/OU=Android/CN=Android/emailAddress=android@android.com'


if false; then

echo -e "\nTo generate OEM's new keypair\n"
if [ -d ${self_certs} ]; then
    rm -rf ${self_certs}
fi
mkdir ${self_certs}

#for x in testkey platform shared media; do
#    echo -e "\n==================================================\n"
#    ./development/tools/make_key ${self_certs}/$x "$subject";
#done
$make_key ${self_certs}/verity "$subject"

# make generate_verity_key (mmma system/extras/verity/)
$generate_verity_key -convert ${self_certs}/verity.x509.pem ${self_certs}/verity_key
mv ${self_certs}/verity_key.pub ${self_certs}/verity_key

fi

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #


function generate_oem_keystore_h()
{
    echo \#ifndef __OEM_KEYSTORE_H
    echo \#define __OEM_KEYSTORE_H
    xxd -i $1 | sed -e 's/unsigned char .* = {/const unsigned char OEM_KEYSTORE[] = {/g' -e 's/unsigned int .* =.*;//g'
    echo \#endif
}

echo -e "\nTo generate keystore\n"

openssl rsa -in ${self_certs}/verity.pk8 -inform DER -pubout -outform DER -out ${self_certs}/verity.der

$keystore_signer ${self_certs}/verity.pk8 ${self_certs}/verity.x509.pem ${self_certs}/keystore.img ${self_certs}/verity.der

generate_oem_keystore_h ${self_certs}/keystore.img > ${self_certs}/oem_keystore.h
### bootable/bootloader/lk/platform/msm_shared/include

sync
