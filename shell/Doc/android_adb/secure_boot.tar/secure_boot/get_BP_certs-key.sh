#!/bin/bash
#########################################################################
# File Name: get_oem_BP.sh
# Author: WangSen
# Email: wangs_hs@163.com
# Created Time: 2018年04月02日 星期一 16时40分48秒
#########################################################################

config_xml="/WorkSpace/Tools/android_adb/secure_boot/config.xml"

self_certs=./out_certs
if [ -d ${self_certs} ]; then
    rm -rf ${self_certs}
fi

# common/tools/sectools/config/8909/8909_secimage.xml #(JTAG ID)
# common/tools/sectools/resources/data_prov_assets/Signing/Local/qc_presigned_certs-key2048_exp3
presigned_certs=${self_certs}/qc_presigned_certs-key2048_exp3
mkdir -p ${presigned_certs}

#openssl_dir=./common/tools/sectools/resources/data_prov_assets/General_Assets/Signing/openssl
if [ ! -e "opensslroot.cfg" ]; then
    echo -e "ERROR: No file found in the wrong directory\n"
    exit 1
fi


openssl genrsa -out ${self_certs}/oem_rootca.key -3 2048 #(for old platform beside sdm660 and sdm845 )
openssl req -new -key ${self_certs}/oem_rootca.key -x509 -out ${self_certs}/oem_rootca.crt -subj /C="US"/ST="CA"/L="SANDIEGO"/O="OEM"/OU="General OEM rootca"/CN="OEM ROOT CA" -days 7300 -set_serial 1 -config opensslroot.cfg


openssl genrsa -out ${self_certs}/oem_attestca.key -3 2048 #(for old platform)
openssl req -new -key ${self_certs}/oem_attestca.key -out ${self_certs}/oem_attestca.csr -subj /C="US"/ST="CA"/L="SANDIEGO"/O="OEM"/OU="General OEM attestation CA"/CN="OEM attestation CA" -days 7300 -config opensslroot.cfg


openssl x509 -req -in ${self_certs}/oem_attestca.csr -CA ${self_certs}/oem_rootca.crt -CAkey ${self_certs}/oem_rootca.key -out ${self_certs}/oem_attestca.crt -set_serial 5 -days 7300 -extfile v3.ext


openssl x509 -in ${self_certs}/oem_rootca.crt -inform PEM -out ${self_certs}/oem_rootca.cer -outform DER
openssl x509 -in ${self_certs}/oem_attestca.crt -inform PEM -out ${self_certs}/oem_attestca.cer -outform DER


mv ${self_certs}/oem_rootca.key ${presigned_certs}/qpsa_rootca.key
mv ${self_certs}/oem_attestca.key ${presigned_certs}/qpsa_attestca.key
mv ${self_certs}/oem_rootca.cer ${presigned_certs}/qpsa_rootca.cer
mv ${self_certs}/oem_attestca.cer ${presigned_certs}/qpsa_attestca.cer

echo -e "\n========================================================\n"
openssl x509 -text -inform DER -in ${presigned_certs}/qpsa_rootca.cer
echo -e "\n========================================================\n"

cd ${presigned_certs}
openssl dgst -sha256 qpsa_rootca.cer > sha256rootcert.txt
cd -
# 8909_fuseblower_USER.xml


#sectools/resources/data_prov_assets/General_Assets/Signing/openssl/config.xml
cp -f ${config_xml} ${presigned_certs}/config.xml

sync
