#!/bin/bash
#########################################################################
# File Name: get_BP_sec_dat.sh
# Author: WangSen
# Email: wangs_hs@163.com
# Created Time: 2018年04月02日 星期一 18时34分42秒
#########################################################################

# cd common/tools/sectools

fuseblower_OEM=config/8909/8909_fuseblower_OEM.xml
fuseblower_QC=config/8909/8909_fuseblower_QC.xml
fuseblower_USER=config/8909/8909_fuseblower_USER.xml
sec_dat=common_output/v1/sec.dat

#boot_images/core/securemsm/secdbgplcy/oem/oem_debug_policy.c
#boot_images/core/storage/tools/deviceprogrammer_ddr/src/firehose/deviceprogrammer_initialize.c
#modem_proc/core/securemsm/secdbgplcy/oem/oem_debug_policy.c
#trustzone_images/core/securemsm/trustzone/qsee/oem/common/src/oem.c


# python sectools.py fuseblower -p <chipset_name> -g –d
#for e.g. for MSM8909 chipset: python sectools.py fuseblower -p 8909 -g -d
#Here,
#-d is for debug information which generate file with fuse information in file <sectools>\ fuseblower_output\v1\debug\secdat_repr.txt
#-p is platform or chipset and config files for platform are in <sectools>\config\
#-g to generate SEC.dat file


python sectools.py fuseblower -e ${fuseblower_OEM} -q ${fuseblower_QC} -u ${fuseblower_USER} -g verbose -vvv

echo -e "\n============================================================\n"
#Command used for verifying if the sec.dat matched the XML configutations
python sectools.py fuseblower --oem_config_path=${fuseblower_OEM} --qc_config_path=${fuseblower_QC} --user_config_path=${fuseblower_USER} --secdat=${sec_dat} --validate
echo -e "\n============================================================\n"

cp -arf ${sec_dat} ./resources/build/fileversion2/sec.dat

sync
