#!/bin/bash
#########################################################################
# File Name: get_oem_BP.sh
# Author: WangSen
# Email: wangs_hs@163.com
# Created Time: 2018年04月02日 星期一 16时40分48秒
#########################################################################

self_certs=./BP_certs

# common/tools/sectools/config/8909/8909_secimage.xml
# 8909_fuseblower_USER.xml

# common/tools/sectools/resources/data_prov_assets/Signing/Local/qc_presigned_certs-key2048_exp3
presigned_certs=${self_certs}/qc_presigned_certs-key2048_exp3

if [ -d ${self_certs} ]; then
    rm -rf ${self_certs}
fi
mkdir -p ${presigned_certs}


#openssl_dir=./common/tools/sectools/resources/data_prov_assets/General_Assets/Signing/openssl
openssl_dir=./openssl

cp -arf ${openssl_dir}/* ${self_certs}
sync


openssl genrsa -out ${self_certs}/oem_rootca.key -3 2048 #(for old platform beside sdm660 and sdm845 )
# openssl genrsa -out oem_rootca.key 2048 #(for SDM660 and sdm845)

#(for old platform)
openssl req -new -key ${self_certs}/oem_rootca.key -x509 -out ${self_certs}/oem_rootca.crt -subj /C="US"/ST="CA"/L="SANDIEGO"/O="OEM"/OU="General OEM rootca"/CN="OEM ROOT CA" -days 7300 -set_serial 1 -config ${self_certs}/opensslroot.cfg
#(for sdm660 and sdm845)
# openssl req -new -sha256 -key oem_rootca.key -x509 -out oem_rootca.crt -subj /C=US/ST=California/L="San Diego"/OU="General Use Test Key (for testing 13 only)"/OU="CDMATechnologies"/O=QUALCOMM/CN="QCT Root CA 1" -days 7300 -set_serial 1 -config opensslroot.cfg -sigopt rsa_padding_mode:pss -sigopt rsa_pss_saltlen:-1 -sigopt digest:sha256



openssl genrsa -out ${self_certs}/oem_attestca.key -3 2048 #(for old platform)
# openssl genrsa -out oem_attestca.key 2048 #(for sdm660 and sdm845)

#(for old platform)
openssl req -new -key ${self_certs}/oem_attestca.key -out ${self_certs}/oem_attestca.csr -subj /C="US"/ST="CA"/L="SANDIEGO"/O="OEM"/OU="General OEM attestation CA"/CN="OEM attestation CA" -days 7300 -config ${self_certs}/opensslroot.cfg
#(for sdm660 and sdm845)
# openssl req -new -key oem_attestca.key -out oem_attestca.csr -subj /C=US/ST=CA/L="San Diego"/OU="CDMA Technologies"/O=QUALCOMM/CN="QUALCOMM Attestation CA" -days 7300 -config opensslroot.cfg



#(for old platform)
openssl x509 -req -in ${self_certs}/oem_attestca.csr -CA ${self_certs}/oem_rootca.crt -CAkey ${self_certs}/oem_rootca.key -out ${self_certs}/oem_attestca.crt -set_serial 5 -days 7300 -extfile ${self_certs}/v3.ext
#(for sdm660 and sdm845)
# openssl x509 -req -in oem_attestca.csr -CA oem_rootca.crt -CAkey oem_rootca.key -out oem_attestca.crt -set_serial 5 -days 7300 -extfile v3.ext -sigopt rsa_padding_mode:pss -sigopt rsa_pss_saltlen:-1 -sigopt digest:sha256


openssl x509 -in ${self_certs}/oem_rootca.crt -inform PEM -out ${self_certs}/oem_rootca.cer -outform DER
openssl x509 -in ${self_certs}/oem_attestca.crt -inform PEM -out ${self_certs}/oem_attestca.cer -outform DER


mv ${self_certs}/config.xml ${presigned_certs}
mv ${self_certs}/oem_rootca.key ${presigned_certs}/qpsa_rootca.key
mv ${self_certs}/oem_attestca.key ${presigned_certs}/qpsa_attestca.key
mv ${self_certs}/oem_rootca.cer ${presigned_certs}/qpsa_rootca.cer
mv ${self_certs}/oem_attestca.cer ${presigned_certs}/qpsa_attestca.cer

echo -e "\n========================================================\n"
openssl x509 -text -inform DER -in ${presigned_certs}/qpsa_rootca.cer
echo -e "\n========================================================\n"


openssl dgst -sha256 ${presigned_certs}/qpsa_rootca.cer > ${presigned_certs}/sha256rootcert.txt


sync
