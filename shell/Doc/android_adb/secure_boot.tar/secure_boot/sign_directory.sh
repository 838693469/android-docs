#!/bin/bash
#########################################################################
# File Name: sign_apq8009.sh
# Author: WangSen
# Email: wangs_hs@163.com
# Created Time: 2018年04月03日 星期二 16时23分51秒
#########################################################################

qcom_platform=$1

sectools_dir=vendor/qcom/non-hlos/common/tools/sectools
secimage_output=${sectools_dir}/secimage_output/${qcom_platform}
SECIMAGE_FILE=${sectools_dir}/config/8909/8909_secimage.xml

if [ "${qcom_platform}" = "8909" ]; then
    if [ "$2" = "mcfg_sw" ]; then
	find_mbn_dir=vendor/qcom/non-hlos/modem_proc/mcfg/configs/mcfg_sw
	sign_out_file=${secimage_output}/mcfg_sw/mcfg_sw.mbn
    elif [ "$2" = "mcfg_hw" ]; then
	find_mbn_dir=vendor/qcom/non-hlos/modem_proc/mcfg/configs/mcfg_hw
	sign_out_file=${secimage_output}/mcfg_hw/mcfg_hw.mbn
    else
	echo -e "\n====== ERROR to sign mbn: '${qcom_platform}' ======\n"
	exit 1
    fi
else
    echo -e "\n====== ERROR NO SUPPORT: '${qcom_platform}' ======\n"
    exit 1
fi


#sign
function sectools_exce()
{
    local file_name=$1

    if [ -e "${file_name}" ]; then
	python ${sectools_dir}/sectools.py secimage -i ${file_name} -c ${SECIMAGE_FILE} -sa
	if [ $? -ne 0 ]; then
	    echo -e "\n====== ERROR Execute result is:     Failure ======\n"
	    exit 1
	fi

	if [ -e "${sign_out_file}" ]; then
	    cp -f ${sign_out_file} ${file_name}
	else
	    echo -e "\n*** CP ERROR FILE NO EXISTS *** '${sign_out_file}'\n"
	    exit 1
	fi
    else
	echo -e "\n*** ERROR FILE NO EXISTS *** '${file_name}'\n"
	exit 1
    fi
}


#main
if [ ! -d ${find_mbn_dir} ]; then
    echo -e "\n*** ERROR DIR NO EXISTS *** '${find_mbn_dir}'\n"
    exit 1
fi

for m in `find ${find_mbn_dir} -name "${2}.mbn"`
do
    echo -e "\n############## SIGN MBN: '$m' #############\n"

    rm -rf ${sign_out_file}
    sectools_exce $m
    echo -e "\n### ================================================================= ###\n"
    sync
done

