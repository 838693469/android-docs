#!/system/bin/sh
#########################################################################
# File Name: adsp_restart.sh
#########################################################################

ps_diag=`ps | grep diag_mdlog | wc -l`
if [ $ps_diag -ne 0 ]; then
    echo "ps_diag_mdlog = $ps_diag"
    /system/bin/diag_mdlog -k
fi

stop sensors

cat /sys/bus/msm_subsys/devices/subsys1/name
echo 'related' > /sys/bus/msm_subsys/devices/subsys1/restart_level
echo 'restart' > /sys/kernel/debug/msm_subsys/adsp
sync

start sensors

if [ -e "/sdcard/sensor.cfg" ]; then
    /system/bin/diag_mdlog -f /sdcard/sensor.cfg -o /sdcard/diag_logs
fi
sync
