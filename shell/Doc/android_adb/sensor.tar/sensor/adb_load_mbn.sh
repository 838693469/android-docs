# -/bin/bash
#########################################################################
# File Name: sensor_load.sh
#########################################################################

adb wait-for-device
adb root
adb wait-for-device
adb remount
adb wait-for-device

#adb shell mount -o remount,rw /firmware
adb shell mount -o rw,remount -t vfat /dev/block/bootdevice/by-name/modem

if [ -e adsp.mbn ]; then
    rm -f adsp.mbn
fi

# /vendor/firmware_mnt
adb push ./adsp.* /vendor/firmware_mnt/image/
adb shell ls -al /vendor/firmware_mnt/image/adsp.*
adb shell sync

#adb shell rm /persist/sensors/sns.reg
#adb shell sync

#adb reboot
