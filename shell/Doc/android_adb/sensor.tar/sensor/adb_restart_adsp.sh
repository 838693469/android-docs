#!/bin/bash
#########################################################################
# File Name: restart_adsp.sh
#########################################################################

adb wait-for-device
adb root
adb wait-for-device

adb shell stop sensors

adb shell cat /sys/bus/msm_subsys/devices/subsys2/name
adb shell "echo 'related' > /sys/bus/msm_subsys/devices/subsys2/restart_level"
adb shell sync

adb shell "echo 'restart' > /sys/kernel/debug/msm_subsys/adsp"

# QXDM发送命令“send_data 75 37 03 48 00”

adb shell start sensors

adb shell sync
