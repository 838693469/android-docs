#!/bin/bash
#########################################################################
# File Name: sensor_logcat.sh
#########################################################################

adb wait-for-device
adb root
adb wait-for-device

if false; then
adb shell setprop debug.qualcomm.sns.daemon 1
adb shell setprop debug.qualcomm.sns.libsensor1 1
adb shell setprop persist.debug.sensors.hal 1
adb shell setprop persist.debug.ar.hal 1
else
adb shell setprop debug.vendor.sns.libsensor1 1
adb shell setprop debug.vendor.sns.daemon 1
adb shell setprop persist.vendor.debug.sensors.hal 1
fi
adb shell getprop persist.vendor.sensors.no_audio

adb shell sync
adb shell logcat -b all -c

adb shell stop
adb shell stop sensors
adb shell start sensors
adb shell start


#adb logcat -v time Sensors:* libsensor1:* qti_sensors_hal:* *:S | tee logcat_sensor.log

