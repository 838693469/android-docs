#!/bin/bash
#########################################################################
# File Name: sensor_conf.sh
#########################################################################
adb wait-for-device
adb root
adb wait-for-device
adb remount
adb shell sync

# /system/vendor/etc/sensors/
# /mnt/vendor/persist
adb shell rm /etc/sensors/sensor_def_qcomdev.conf
adb shell sync
adb push sensor_def_qcomdev.conf /system/etc/sensors/sensor_def_qcomdev.conf
adb shell chmod 644 /system/etc/sensors/sensor_def_qcomdev.conf
adb shell sync
adb shell rm /persist/sensors/sns.reg
adb shell sync

#adb reboot
