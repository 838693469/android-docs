#!/bin/bash
#########################################################################
# File Name: get_sensor.sh
#########################################################################
adb wait-for-device
adb root
adb wait-for-device

adb shell sns_dsps_tc0001 > sns_dsps_tc0001.log
adb shell sns_regedit_ssi -r > sns_regedit_ssi.r.log
adb shell dumpsys sensorservice > dumpsys.sensorservice

adb pull /system/etc/sensors/sensor_def_qcomdev.conf
adb pull /persist/sensors/sns.reg

adb shell sync
