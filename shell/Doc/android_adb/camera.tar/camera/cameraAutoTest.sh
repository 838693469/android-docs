#!/system/bin/sh
Path="/sdcard/camera_test.jpg"
removeInfo="Remove old picture successfully."
if [ "$1" = "--help" ]; then
   echo "raw usage: "$0" cameraId from raw"
   echo "camreraid: [mainBack = 0]   [subback = 2]"
   echo "from:      hqftm"
   echo "raw:       raw"
   echo "--------------------------------------"
   echo "ata usage: "$0" cameraid size isfocus"
   echo "cameraid:  [front = 0]      [mainback = 1]      [subback = 2]"
   echo "size :     [max = 0]        [middle = 1]        [min = 2]"
   echo "isfocus:   [focus = 0]      [not focus = 1]"
   exit 0
fi

if [ "$#" != "3" ]; then
   echo "The number of input parameters is not correct."
   exit 0
fi
if [[ "$1" != [0-2] ]]; then
   echo "First Parameter is error. Please input correct First parameter[0-2]"
   exit 0;
fi

if [ "$3" = "raw" ]; then
#   echo "can't take raw picture now exit"
#   exit 0;

   if [ "$1" = "0" ]; then
      camera=0
      Path="/sdcard/master.jpg"
      if [ -a "$Path" ]; then
      rm $Path
      echo $removeInfo
      fi
   elif [ "$1" = "1" ]; then
      echo "front camera can't take raw picture"
      exit 0
   elif [ "$1" = "2" ]; then
      camera=2
      Path="/sdcard/slave.jpg"
      if [ -a "$Path" ]; then
      rm $Path
      echo $removeInfo
      fi
   fi
am start -a android.media.action.IMAGE_CAPTURE --ei "android.intent.extras.CAMERA_FACING" $camera --es "from" $2 --es "raw" $3

elif [[ "$3" = [0-1] ]];then

   if [ -a "$Path" ]; then
      rm $Path
      echo $removeInfo
   fi

   if [[ "$2" != [0-2] ]]; then
      echo "Second Parameter is error. Please input correct Second parameter[0-2]"
      exit 0;
   fi

   if [ "$1" = "0" ]; then
      camera=2
   elif [ "$1" = "1" ]; then
      camera=0
   elif [ "$1" = "2" ]; then
      camera=1
   fi
am start -n com.huaqin.factory\/.ata.CameraAutoTest --ei "cameraNum" $camera --ei "solution" $2 --ei "autofocus" $3

fi
#$2 0:focus //1: don't focus

num=0
while [[ $num -lt 12 ]]
do
if [ -a "$Path" ]; then
   echo "Take Picture successfully"
   exit 0
fi
let "num++"
#echo $num
sleep 1
done

if [ ! -a "$Path" ]; then

   echo "Take Picture fail"
   exit 0
fi
exit 0
