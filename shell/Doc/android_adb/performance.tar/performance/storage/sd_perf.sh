#!/bin/bash
#########################################################################
# File Name: recovery.sh
#########################################################################

SD_PATH=/sys/class/mmc_host/mmc1

SAVE_LOG_ROOT=sd_logs
if [ -d "${SAVE_LOG_ROOT}" ]; then
    rm -rf ${SAVE_LOG_ROOT}
fi
mkdir -p ${SAVE_LOG_ROOT}

adb wait-for-device
adb root
adb wait-for-device

boot_mode=`adb shell getprop ro.bootmode`
echo -e "\n Android boot Mode is : '${boot_mode}' \n"
adb shell "echo 8 > /proc/sys/kernel/printk"
adb shell dmesg -C
echo -e "\n[`date +"%Y-%m-%d %H:%M:%S"`] ====== begin ======\n"


if false; then
    echo -e "\n[`date +"%Y-%m-%d %H:%M:%S"`] ====== set performance mode ======\n"
    #1. CPU performance mode 
    adb root
    adb shell setenforce 0
    adb shell stop thermal-engine
    adb shell stop mpdecision
    adb shell stop perfd
    adb shell "echo 4 > /sys/devices/system/cpu/cpu0/core_ctl/min_cpus"
    adb shell "echo 4 > /sys/devices/system/cpu/cpu4/core_ctl/min_cpus"
    adb shell "echo 1 > /sys/devices/system/cpu/cpu0/online"
    adb shell "echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"
    adb shell "echo 1 > /sys/devices/system/cpu/cpu1/online"
    adb shell "echo performance > /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor"
    adb shell "echo 1 > /sys/devices/system/cpu/cpu2/online"
    adb shell "echo performance > /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor"
    adb shell "echo 1 > /sys/devices/system/cpu/cpu3/online"
    adb shell "echo performance > /sys/devices/system/cpu/cpu3/cpufreq/scaling_governor"
    adb shell "echo 1 > /sys/devices/system/cpu/cpu4/online"
    adb shell "echo performance > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor"
    adb shell "echo 1 > /sys/devices/system/cpu/cpu5/online"
    adb shell "echo performance > /sys/devices/system/cpu/cpu5/cpufreq/scaling_governor"
    adb shell "echo 1 > /sys/devices/system/cpu/cpu6/online"
    adb shell "echo performance > /sys/devices/system/cpu/cpu6/cpufreq/scaling_governor"
    adb shell "echo 1 > /sys/devices/system/cpu/cpu7/online"
    adb shell "echo performance > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor"
    #2. disable lpm 
    adb shell "echo Y > /sys/module/lpm_levels/parameters/sleep_disabled"
fi


echo "EMMC: `adb shell cat /sys/class/huaqin/interface/hw_info/emmc`" > ${SAVE_LOG_ROOT}/tablet_info.txt
echo -e "\n==============================================\n" >> ${SAVE_LOG_ROOT}/tablet_info.txt
echo "SD clk_scaling: `adb shell cat ${SD_PATH}/clk_scaling/enable`" >> ${SAVE_LOG_ROOT}/tablet_info.txt
echo -e "\n==============================================\n" >> ${SAVE_LOG_ROOT}/tablet_info.txt
adb shell cat /sys/kernel/debug/mmc1/ios >> ${SAVE_LOG_ROOT}/tablet_info.txt

adb shell screencap -p > ${SAVE_LOG_ROOT}/test_config.png

adb shell "echo 0 > ${SD_PATH}/perf"
adb shell "echo 1 > ${SD_PATH}/perf"
adb shell cat ${SD_PATH}/perf > ${SAVE_LOG_ROOT}/perf_befor.txt

read -p "Whether to continue [Yes] : " SIZECHECK
adb wait-for-device

adb shell cat ${SD_PATH}/perf > ${SAVE_LOG_ROOT}/perf_after.txt

adb shell screencap -p > ${SAVE_LOG_ROOT}/test_results.png


adb shell dmesg > ${SAVE_LOG_ROOT}/dmesg.log
adb shell logcat -b kernel -d > ${SAVE_LOG_ROOT}/logcat_kernel.log

#adb shell logcat -b all -d > ${SAVE_LOG_ROOT}/logcat_all.log
#adb shell bugreport > ${SAVE_LOG_ROOT}/bugreport.log
sync
