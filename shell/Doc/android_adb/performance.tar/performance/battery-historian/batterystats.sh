#!/bin/bash
#########################################################################
# File Name: batterystats.sh
#########################################################################

adb shell dumpsys batterystats --reset
adb shell dumpsys batterystats --enable full-wake-history

adb shell dumpsys batterystats > batterystats.txt


python historian.py batterystats.txt > batterystats.html
