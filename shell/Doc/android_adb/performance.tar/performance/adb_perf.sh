#!/bin/bash
#########################################################################
# File Name: adb_reboot.sh
#########################################################################

SAVE_LOG_ROOT=logs
if [ -d "${SAVE_LOG_ROOT}" ]; then
    rm -rf ${SAVE_LOG_ROOT}
fi
mkdir -p ${SAVE_LOG_ROOT}

adb reboot
echo -e "\n[`date +"%Y-%m-%d %H:%M:%S"`] ====== begin ======\n"

adb wait-for-device
adb root
adb wait-for-device
adb remount
adb wait-for-device

echo -e "\n[`date +"%Y-%m-%d %H:%M:%S"`] ====== dev.bootcomplete ======\n"
result=`adb shell getprop dev.bootcomplete`
while [ "z${result}" != "z1" ]
do
    result=`adb shell getprop dev.bootcomplete`
done
echo -e "\n[`date +"%Y-%m-%d %H:%M:%S"`] ====== dev.bootcomplete ======\n"

adb shell cat /proc/cmdline > ${SAVE_LOG_ROOT}/cmdline.log
adb shell dmesg > ${SAVE_LOG_ROOT}/dmesg.log
adb logcat -b events -d > ${SAVE_LOG_ROOT}/logcat_events.txt
adb logcat -v time thread -d > ${SAVE_LOG_ROOT}/logcat.txt

sync
