#!/bin/bash
#########################################################################
# File Name: adb_services.sh
# Author: WangSen
# Email: wangs_hs@163.com
# Created Time: 2017年11月28日 星期二 14时37分27秒
#########################################################################

#adb wait-for-device
#adb root
#adb wait-for-device
#adb disable-verity
#adb reboot

adb wait-for-device
adb root
adb remount
adb wait-for-device
adb push services.jar /system/framework/

adb shell ls -al /system/framework/services.jar

adb reboot
