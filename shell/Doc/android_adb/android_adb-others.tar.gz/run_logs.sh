#!/system/bin/sh
#########################################################################
# File Name: adb_run.sh
#########################################################################

Count=$1

LOG_TAR_NAME=/cache/wangs.tar
if [ -f ${LOG_TAR_NAME} ]; then
    rm -rf ${LOG_TAR_NAME}
fi
LOG_PATH=/cache/wangs
if [ ! -d ${LOG_PATH} ]; then
    mkdir -p ${LOG_PATH}
fi

echo "====== $0: PID of this script: $$ ======\n"

dmesg > ${LOG_PATH}/dmesg_${Count}.log
sync

cat /proc/kmsg > ${LOG_PATH}/kmsg_${Count}.log 2>&1 &
logcat -b all -v time > ${LOG_PATH}/logcat_${Count}.log 2>&1 &
sync

sleep 3
#bugreport > ${LOG_PATH}/bugreport_${Count}.log
sync

cat /proc/mounts > ${LOG_PATH}/mounts.log
cat /proc/meminfo > ${LOG_PATH}/meminfo.log
screencap -p ${LOG_PATH}/screencap.png
sync

tar cvf ${LOG_TAR_NAME} ${LOG_PATH}
sync

echo "success : ${Count}\n"
sync
