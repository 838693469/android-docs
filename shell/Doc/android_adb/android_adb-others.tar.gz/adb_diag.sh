#!/bin/bash
#########################################################################
# File Name: adb_diag.sh
# Author: WangSen
# Email: wangs_hs@163.com
# Created Time: 2017年09月29日 星期五 18时52分25秒
#########################################################################

adb wait-for-device
adb root
adb wait-for-device

adb shell setprop persist.sys.usb.config diag,adb
#adb shell setprop persist.sys.usb.config diag,serial_smd,rmnet_qti_bam,adb
#adb shell setprop sys.usb.config mtp,diag,adb

# 打开diag端口：*#*#717717#*#*
