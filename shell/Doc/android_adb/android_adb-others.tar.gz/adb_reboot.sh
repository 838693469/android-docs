#!/bin/bash
#########################################################################
# File Name: adb_reboot.sh
#########################################################################

if [ -d "LOGS" ]; then
    rm -rf LOGS
fi
mkdir LOGS
cd LOGS

adb wait-for-device

echo -e "\n[`date +"%Y-%m-%d %H:%M:%S"`] ====== begin ======\n"
adb reboot

adb wait-for-device
adb root

adb wait-for-device
adb shell "dmesg > /data/dmesg.log"
adb wait-for-device
adb shell "logcat -v time > /data/logcat.log"
adb wait-for-device
adb shell "logcat -b events -v time > /data/logcat_events.log"
adb wait-for-device
adb shell "logcat -b kernel -v time > /data/logcat_kernel.log"

adb wait-for-device
adb pull /data/dmesg.log
adb wait-for-device
adb pull /data/logcat.log
adb wait-for-device
adb pull /data/logcat_event.log

result=`adb shell getprop dev.bootcomplete`
echo -e "====== '$result' ======"
while [ "z${result}" != "z1" ]
do
    result=`adb shell getprop dev.bootcomplete`
done
echo -e "\n[`date +"%Y-%m-%d %H:%M:%S"`] ====== end ======\n"
echo -e "====== '$result' ======"
