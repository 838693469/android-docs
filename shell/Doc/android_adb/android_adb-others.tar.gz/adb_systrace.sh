#!/bin/bash
#########################################################################
# File Name: adb_systrace.sh
#########################################################################

LOG_PATH=~/Downloads

NOW_DATE=`date +%Y%m%d_%H-%M-%S`

python systrace.py -o ${LOG_PATH}/systrace_${NOW_DATE}.html \
    -b 32768 -t 10 \
    gfx input view webview wm am sm audio video camera hal app res dalvik rs bionic power pm ss database network sched irq freq idle disk mmc load sync workq memreclaim regulators binder_driver binder_lock pagecache
