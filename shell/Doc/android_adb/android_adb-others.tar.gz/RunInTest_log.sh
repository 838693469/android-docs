#########################################################################
# File Name: get_log.sh
# Author: WangSen
# Email: wangs_hs@163.com
# Created Time: 2016年10月13日 星期四 16时04分49秒
#########################################################################
#!/bin/bash

LOG_NAME="RunInTest"
ADB_SAVE_LOG_PATH="/sdcard/save_log"

SAVE_LOG_ROOT=~/Downloads

SAVE_LOG_PATH=$SAVE_LOG_ROOT/RunInTest
SAVE_ZIP_NAME="RunInTest"
if [ $1 ]; then
    SAVE_LOG_PATH=$SAVE_LOG_ROOT/RunInTest/$1
    SAVE_ZIP_NAME=$1
    echo -e "====== $SAVE_ZIP_NAME \n"
fi
echo -e "====== $SAVE_LOG_PATH \n"

if [ ! -d $SAVE_LOG_PATH ]; then
    mkdir -p $SAVE_LOG_PATH
fi

cd $SAVE_LOG_PATH

NOW_DATE=`date +%Y-%m-%d_%H:%M:%S`
echo -e "====== ${NOW_DATE} \n"

SAVE_LOG_NAME=${LOG_NAME}_${NOW_DATE}
echo -e "====== $SAVE_LOG_NAME \n"

adb shell "screencap -p ${ADB_SAVE_LOG_PATH}/screencap_${NOW_DATE}.png"
echo -e "====== adb shell \"screencap -p ${ADB_SAVE_LOG_PATH}/screencap_${NOW_DATE}.png\" \n"
adb shell sync

#adb shell "ls -al ${ADB_SAVE_LOG_PATH}"
#if [ $? ]; then
#    echo "====== No LOG !!! return: $?"
#    exit
#fi


#adb push ~/Downloads/Tools/busybox-armv7l /data
#adb shell "chmod +x /data/busybox-armv7l"

#adb shell "/data/busybox-armv7l tar cvf /data/${SAVE_LOG_NAME}.tar ${ADB_SAVE_LOG_PATH}"
#echo "====== adb shell \"/data/busybox-armv7l tar cvf /data/${SAVE_LOG_NAME}.tar ${ADB_SAVE_LOG_PATH}\""


rm -rf ${NOW_DATE}
mkdir -p ${NOW_DATE}
sync

adb pull ${ADB_SAVE_LOG_PATH} ${NOW_DATE}
echo -e "====== adb pull ${ADB_SAVE_LOG_PATH} ${NOW_DATE} \n"
adb shell sync

echo "======================================================"
#zip -r -v ${SAVE_ZIP_NAME}.zip ${NOW_DATE}
sync
echo "======================================================"

cd -
