#!/bin/bash
#########################################################################
# File Name: recovery.sh
# Author: WangSen
# Email: wangs_hs@163.com
# Created Time: 2018年05月24日 星期四 11时14分10秒
#########################################################################

SAVE_LOG_ROOT=logs
if [ -d "${SAVE_LOG_ROOT}" ]; then
    rm -rf ${SAVE_LOG_ROOT}
fi
mkdir -p ${SAVE_LOG_ROOT}

echo -e "\n[`date +"%Y-%m-%d %H:%M:%S"`] ====== begin ======\n"

adb wait-for-device
adb root
adb wait-for-device

boot_mode=`adb shell getprop ro.bootmode`
echo -e "\n Android boot Mode is : '${boot_mode}' \n"


adb shell "echo 'file phy-msm-usb.c +p' > /sys/kernel/debug/dynamic_debug/control"
adb shell "echo 'file ci13xxx_udc.c +p' > /sys/kernel/debug/dynamic_debug/control"
adb shell "echo 'file composite.c +p' > /sys/kernel/debug/dynamic_debug/control"
adb shell "echo 'file android.c +p' > /sys/kernel/debug/dynamic_debug/control"
adb shell "echo 'file f_mtp.c +p' > /sys/kernel/debug/dynamic_debug/control"
adb shell "echo 'file f_fs.c +p' > /sys/kernel/debug/dynamic_debug/control"
adb shell "echo 'file f_diag.c +p' > /sys/kernel/debug/dynamic_debug/control"

adb shell "echo 8 > /proc/sys/kernel/printk"

adb shell logcat -v time -b kernel -d > logcat_kernel.log

#adb shell getenforce

#adb shell dmesg > ${SAVE_LOG_ROOT}/dmesg.log
#adb shell logcat -b kernel -d > ${SAVE_LOG_ROOT}/logcat_kernel.log
#adb shell logcat -b all -d > ${SAVE_LOG_ROOT}/logcat_all.log
#adb shell bugreport > ${SAVE_LOG_ROOT}/bugreport.log


#adb shell cat /d/tzdbg/qsee_log > ${SAVE_LOG_ROOT}/TZ_qsee_log.txt
#adb shell cat /d/tzdbg/log > ${SAVE_LOG_ROOT}/TZ_log.txt

sync
