#########################################################################
# File Name: adb_push_directory.sh
# Created Time: 2016年09月07日 星期三 18时31分44秒
#########################################################################
#!/bin/bash

Directory=$1
echo "Input Directory -> $Directory"

InPath=$2
echo -e "Input InPath -> $InPath \n"

for file in `ls $Directory`
do
    echo -e "====> file: $file \n"
    if [ -s $file ]; then
        adb push $Directory/$file $InPath
    fi
done

adb shell sync
