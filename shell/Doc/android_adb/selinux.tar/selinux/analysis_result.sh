#!/bin/bash
#########################################################################
# File Name: analysis_result.sh
# Author: WangSen
# Email: wangs_hs@163.com
# Created Time: 2018年05月22日 星期二 14时16分43秒
#########################################################################

# Read the run args
# Quick analysis android issues tools, Writed by mtk71029 <yanghui.li@medaitek.com> V 0025
# -d logdir         the dir of log, maybe mtklog
# -f file           the log file
# -o outputfile     the filename of analysis, default is analysis_result.txt or HTML UI

echo -e "\n====== Prepare for analysis: $1 ======\n"
java -jar QAAT-ProGuard.jar -d $1

sync
