#!/bin/bash
#########################################################################
# File Name: thermal_engine.sh
#########################################################################

adb wait-for-device
adb root
adb wait-for-device

adb shell thermal-engine -o > thermal-engine.conf
adb shell sync


