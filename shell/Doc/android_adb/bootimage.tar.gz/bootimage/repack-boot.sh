 ./mkbootimg --cmdline 'no_console_suspend=1 console=null'  --kernel zImage --ramdisk boot/boot.img-ramdisk.gz -o boot.img --base 02e00000
