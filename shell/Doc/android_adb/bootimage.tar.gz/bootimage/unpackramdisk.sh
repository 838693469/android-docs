#!/bin/bash
#########################################################################
# File Name: unpackramdisk.sh
# Author: WangSen
# Email: wangs_hs@163.com
# Created Time: 2017年08月22日 星期二 17时29分14秒
#########################################################################

echo "gunzip -c $1 | cpio -i"
gunzip -c $1 | cpio -i
