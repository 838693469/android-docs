#!/bin/bash
#########################################################################
# File Name: dtc.sh
# Author: WangSen
# Email: wangs_hs@163.com
# Created Time: 2017年04月17日 星期一 17时22分32秒
#########################################################################

OUT_PATH=`pwd`
NOW_DATE=`date +%Y%m%d_%H-%M-%S`


#DTB_FILE_PATH=${OUT_PATH}/obj/KERNEL_OBJ/arch/arm64/boot/dts/qcom/msm8917-pmi8937-qrd-sku5.dtb
#DTB_FILE_PATH=${OUT_PATH}/obj/KERNEL_OBJ/arch/arm64/boot/dts/qcom/msm8953-qrd-sku3.dtb
#DTB_FILE_PATH=${OUT_PATH}/obj/KERNEL_OBJ/arch/arm/boot/dts/qcom/apq8009-mtp-wcd9326-refboard.dtb
#DTB_FILE_PATH=${OUT_PATH}/obj/KERNEL_OBJ/arch/arm64/boot/dts/qcom/tina-overlay.dtbo
DTB_FILE_PATH=${OUT_PATH}/obj/KERNEL_OBJ/arch/arm64/boot/dts/qcom/sdm670.dtb


DTC_TOOL_PATH=${OUT_PATH}/obj/KERNEL_OBJ/scripts/dtc/dtc
DTC_FILE_NAME=`basename ${DTB_FILE_PATH}`

${DTC_TOOL_PATH} -I dtb \
    -O dts \
    -s \
    ${DTB_FILE_PATH} \
    -o ${DTC_FILE_NAME}
sync
