#!/bin/bash
#########################################################################
# File Name: make_bootimage.sh
# Author: WangSen
# Email: wangs_hs@163.com
# Created Time: 2018年06月29日 星期五 10时11分20秒
#########################################################################

set -v

my_ramdisk_path=/WorkSpace/Huaqin/msm8909-la-3-0-1_dev/out/target/product/hq_msm8909
#my_ramdisk_path=out/target/product/hq_msm8909go

#my_kernel_path=/WorkSpace/Huaqin/msm8909-la-3-0-1_dev/out/target/product/hq_msm8909
my_kernel_path=out/target/product/hq_msm8909go

boot_path=out/target/product/hq_msm8909go


out/host/linux-x86/bin/mkbootimg  --kernel ${my_kernel_path}/kernel --ramdisk ${my_ramdisk_path}/ramdisk.img \
    --base 0x80000000 --pagesize 2048 \
    --cmdline "console=ttyHSL0,115200,n8 androidboot.console=ttyHSL0 androidboot.hardware=qcom msm_rtb.filter=0x237 ehci-hcd.park=3 androidboot.bootdevice=7824900.sdhci lpm_levels.sleep_disabled=1 androidboot.memcg=false earlyprintk buildvariant=userdebug" \
    --os_version 8.1.0 --os_patch_level 2017-12-05  \
    --output ${boot_path}/boot.img

out/host/linux-x86/bin/boot_signer /boot ${boot_path}/boot.img \
    build/target/product/security/verity.pk8 \
    build/target/product/security/verity.x509.pem \
    ${boot_path}/boot.img

sync

