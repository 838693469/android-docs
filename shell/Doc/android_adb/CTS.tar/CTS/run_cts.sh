#!/bin/bash
#########################################################################
# File Name: run_cts.sh
#########################################################################

# export aapt tool patch from android path
export PATH=$PATH:/WorkSpace/ASUS/ZB555KL/prebuilts/sdk/tools/linux/bin

./cts-tradefed

run cts -m CtsSensorTestCases -t android.hardware.cts.SingleSensorTests#testAccelerometer_1hz -o
