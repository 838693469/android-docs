#!/bin/bash
#########################################################################
# File Name: ramdump_parser.sh
#########################################################################

local_path=`pwd`

#adb shell "echo 1 > /sys/module/subsystem_restart/parameters/enable_ramdumps"

ramdump_logs_dir=${local_path}/Port_COM9
vmlinux_path=${local_path}/vmlinux
ramparse_out_dir=${local_path}/out

android_dir=/WorkSpace/Huaqin/msm8909-la-3-0-1_dev
gdb_path=${android_dir}/prebuilts/gcc/linux-x86/arm/arm-eabi-4.8/bin/arm-eabi-gdb
nm_path=${android_dir}/prebuilts/gcc/linux-x86/arm/arm-eabi-4.8/bin/arm-eabi-nm

toolchain_dir=/WorkSpace/Tools/qcom_Tools/linaro-toolchain
gdb64_path=${toolchain_dir}/gcc-linaro-4.9-2014.11-x86_64_aarch64-elf/bin/aarch64-none-elf-gdb
nm64_path=${toolchain_dir}/gcc-linaro-4.9-2014.11-x86_64_aarch64-elf/bin/aarch64-none-elf-nm
objdump64_path=${toolchain_dir}/gcc-linaro-4.9-2014.11-x86_64_aarch64-elf/bin/aarch64-none-elf-objdump

# git clone git://www.codeaurora.org/platform/vendor/qcom-opensource/tools.git
#ramparse_tools_dir=${android_dir}/vendor/qcom/opensource/tools/linux-ramdump-parser-v2

# git clone git://codeaurora.org/quic/la/platform/vendor/qcom-opensource/tools
# git clone git://codeaurora.org/platform/vendor/qcom-opensource/tools
ramparse_tools_dir=${local_path}/tools/linux-ramdump-parser-v2

echo -e "\n===================================================\n"
strings ${vmlinux_path} | grep "Linux version"
strings ${ramdump_logs_dir}/DDRCS0.BIN | grep "Linux version"
#strings tz.elf | grep "OEM_IMAGE_UUID_STRING"
echo -e "\n===================================================\n"


cd ${ramparse_tools_dir}
python ramparse.py --vmlinux ${vmlinux_path} \
    --nm-path ${nm_path} \
    --gdb-path ${gdb_path} \
    --objdump-path ${objdump64_path} \
    --auto-dump ${ramdump_logs_dir} \
    --outdir ${ramparse_out_dir} \
    --everything \
    --print-watchdog-time \
    --32-bit

#python ramparse.py -v ${vmlinux_path} -n ${nm_path} -g ${gdb_path} -j ${objdump64_path} -a ${ramdump_logs_dir} -o ${ramparse_out_dir} -x
cd -

echo -e "\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"
sync
