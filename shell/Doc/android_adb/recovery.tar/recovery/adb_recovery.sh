#!/bin/bash
#########################################################################
# File Name: recovery.sh
#########################################################################

SAVE_LOG_ROOT=logs
if [ -d "${SAVE_LOG_ROOT}" ]; then
    rm -rf ${SAVE_LOG_ROOT}
fi
mkdir -p ${SAVE_LOG_ROOT}

echo -e "\n[`date +"%Y-%m-%d %H:%M:%S"`] ====== begin ======\n"

adb wait-for-recovery
adb root
adb wait-for-recovery

boot_mode=`adb shell getprop ro.bootmode`
echo -e "\n Android boot Mode is : '${boot_mode}' \n"

adb shell dmesg > ${SAVE_LOG_ROOT}/dmesg_1.log
adb shell dmesg -C

read -p "Would you Continue to get a valid log [Y] : " SIZECHECK

adb pull /cache/recovery ${SAVE_LOG_ROOT}/
adb pull /tmp/recovery.log ${SAVE_LOG_ROOT}/recovery_1.log
adb shell dmesg > ${SAVE_LOG_ROOT}/dmesg_2.log
sync
