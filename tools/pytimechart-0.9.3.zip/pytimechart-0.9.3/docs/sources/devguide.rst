pyTimechart Developer Guide
===========================
This section is here to explain how to extend pyTimechart to parse your own traces

