# for py2exe.
try:
    import enthought.pyface.ui.wx.about_dialog
    import enthought.pyface.ui.wx.application_window
    import enthought.pyface.ui.wx.clipboard
    import enthought.pyface.ui.wx.confirmation_dialog
    import enthought.pyface.ui.wx.dialog
    import enthought.pyface.ui.wx.directory_dialog
    import enthought.pyface.ui.wx.file_dialog
    import enthought.pyface.ui.wx.gui
    import enthought.pyface.ui.wx.heading_text
    import enthought.pyface.ui.wx.image_cache
    import enthought.pyface.ui.wx.image_resource
    import enthought.pyface.ui.wx.__init__
    import enthought.pyface.ui.wx.init
    import enthought.pyface.ui.wx.ipython_widget
    import enthought.pyface.ui.wx.message_dialog
    import enthought.pyface.ui.wx.progress_dialog
    import enthought.pyface.ui.wx.python_editor
    import enthought.pyface.ui.wx.python_shell
    import enthought.pyface.ui.wx.resource_manager
    import enthought.pyface.ui.wx.splash_screen
    import enthought.pyface.ui.wx.split_widget
    import enthought.pyface.ui.wx.system_metrics
    import enthought.pyface.ui.wx.widget
    import enthought.pyface.ui.wx.window
    import enthought.pyface.ui.wx.window
except:
 pass
