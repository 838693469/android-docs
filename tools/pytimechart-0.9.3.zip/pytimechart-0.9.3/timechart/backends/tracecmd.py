def detect_tracecmd(fn):
    #todo
    return None
